nome_arquivo = 'data_train_6.csv';

csvwrite(nome_arquivo,data_tr)